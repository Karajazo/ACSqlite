package com.example.ac_dbsqliteyapi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ProductoAdapter extends BaseAdapter {
    private Context context;
    private List<Producto> productos;
    private LayoutInflater inflater;

    public ProductoAdapter(Context context) {
        this.context = context;
        this.productos = new ArrayList<>();
        this.inflater = LayoutInflater.from(context);
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos != null ? productos : new ArrayList<>();
        notifyDataSetChanged();
    }

    public void addProducto(Producto producto) {
        if (productos == null) {
            productos = new ArrayList<>();
        }
        productos.add(producto);
        notifyDataSetChanged();
    }

    public void clearProductos() {
        if (productos != null) {
            productos.clear();
            notifyDataSetChanged();
        }
    }

    @Override
    public int getCount() {
        return productos != null ? productos.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        return productos != null ? productos.get(position) : null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.producto_item, parent, false);
            holder = new ViewHolder();
            holder.tvNombre = convertView.findViewById(R.id.tvNombre);
            holder.tvDescripcion = convertView.findViewById(R.id.tvDescripcion);
            holder.tvPrecio = convertView.findViewById(R.id.tvPrecio);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Producto producto = productos.get(position);
        if (producto != null) {
            holder.tvNombre.setText(producto.getNombre());
            holder.tvDescripcion.setText(producto.getDescripcion());
            holder.tvPrecio.setText("$" + String.format("%.2f", producto.getPrecio()));
        }

        return convertView;
    }

    private static class ViewHolder {
        TextView tvNombre;
        TextView tvDescripcion;
        TextView tvPrecio;
    }
}

