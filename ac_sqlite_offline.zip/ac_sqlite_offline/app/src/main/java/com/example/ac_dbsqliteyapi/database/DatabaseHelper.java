package com.example.ac_dbsqliteyapi.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "usuarios_db";
    private static final int DATABASE_VERSION = 1;

    // Tabla Roles
    public static final String TABLE_ROLES = "roles";
    public static final String COLUMN_ROL_ID = "id";
    public static final String COLUMN_ROL_NOMBRE = "nombre";
    public static final String COLUMN_ROL_DESCRIPCION = "descripcion";
    public static final String COLUMN_ROL_CREATED_DATE = "created_date";
    public static final String COLUMN_ROL_LAST_MODIFIED_DATE = "last_modified_date";

    // Tabla Usuarios
    public static final String TABLE_USUARIOS = "usuarios";
    public static final String COLUMN_USUARIO_ID = "id";
    public static final String COLUMN_USUARIO_NOMBRE = "nombre";
    public static final String COLUMN_USUARIO_EMAIL = "email";
    public static final String COLUMN_USUARIO_TELEFONO = "telefono";
    public static final String COLUMN_USUARIO_ACTIVO = "activo";
    public static final String COLUMN_USUARIO_ROL_ID = "rol_id";
    public static final String COLUMN_USUARIO_CREATED_DATE = "created_date";
    public static final String COLUMN_USUARIO_LAST_MODIFIED_DATE = "last_modified_date";
    public static final String COLUMN_USUARIO_SYNCED = "synced"; // Para saber si está sincronizado con la API

    // SQL para crear tabla Roles
    private static final String CREATE_TABLE_ROLES = 
        "CREATE TABLE " + TABLE_ROLES + " (" +
        COLUMN_ROL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
        COLUMN_ROL_NOMBRE + " TEXT NOT NULL, " +
        COLUMN_ROL_DESCRIPCION + " TEXT, " +
        COLUMN_ROL_CREATED_DATE + " TEXT, " +
        COLUMN_ROL_LAST_MODIFIED_DATE + " TEXT" +
        ")";

    // SQL para crear tabla Usuarios
    private static final String CREATE_TABLE_USUARIOS = 
        "CREATE TABLE " + TABLE_USUARIOS + " (" +
        COLUMN_USUARIO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
        COLUMN_USUARIO_NOMBRE + " TEXT NOT NULL, " +
        COLUMN_USUARIO_EMAIL + " TEXT NOT NULL, " +
        COLUMN_USUARIO_TELEFONO + " TEXT, " +
        COLUMN_USUARIO_ACTIVO + " INTEGER NOT NULL DEFAULT 1, " +
        COLUMN_USUARIO_ROL_ID + " INTEGER NOT NULL, " +
        COLUMN_USUARIO_CREATED_DATE + " TEXT, " +
        COLUMN_USUARIO_LAST_MODIFIED_DATE + " TEXT, " +
        COLUMN_USUARIO_SYNCED + " INTEGER NOT NULL DEFAULT 0, " +
        "FOREIGN KEY(" + COLUMN_USUARIO_ROL_ID + ") REFERENCES " + TABLE_ROLES + "(" + COLUMN_ROL_ID + ")" +
        ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_ROLES);
        db.execSQL(CREATE_TABLE_USUARIOS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USUARIOS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ROLES);
        onCreate(db);
    }
}

