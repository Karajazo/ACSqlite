package com.example.ac_dbsqliteyapi;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ac_dbsqliteyapi.database.UsuarioDAO;
import com.example.ac_dbsqliteyapi.models.Rol;
import com.example.ac_dbsqliteyapi.models.Usuario;
import com.example.ac_dbsqliteyapi.utils.NetworkChangeReceiver;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements NetworkChangeReceiver.NetworkChangeListener {

    private static final String BASE_URL = "http://10.0.2.2:5000/api/v1/Usuario";
    private static final String ROLES_URL = "http://10.0.2.2:5000/api/v1/Rol";
    
    private EditText etNombre, etEmail, etTelefono;
    private Spinner spinnerRoles;
    private Button btnAgregar;
    private ListView listViewUsuarios;
    private TextView tvEstadoConexion;
    private View indicatorConexion;
    private ProgressBar progressBar;
    private UsuarioAdapter adapter;
    private List<Usuario> listaUsuarios;
    private List<Rol> listaRoles;
    private ArrayAdapter<Rol> rolesAdapter;
    private Gson gson;
    private ExecutorService executorService;
    private UsuarioDAO usuarioDAO;
    private NetworkChangeReceiver networkReceiver;
    private boolean isOnline = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gson = new GsonBuilder().create();
        executorService = Executors.newFixedThreadPool(2);
        usuarioDAO = new UsuarioDAO(this);
        usuarioDAO.open();

        etNombre = findViewById(R.id.etNombre);
        etEmail = findViewById(R.id.etEmail);
        etTelefono = findViewById(R.id.etTelefono);
        spinnerRoles = findViewById(R.id.spinnerRoles);
        btnAgregar = findViewById(R.id.btnAgregar);
        
        // Inicializar lista de roles
        listaRoles = new ArrayList<>();
        rolesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, listaRoles);
        rolesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRoles.setAdapter(rolesAdapter);
        listViewUsuarios = findViewById(R.id.listViewUsuarios);
        tvEstadoConexion = findViewById(R.id.tvEstadoConexion);
        indicatorConexion = findViewById(R.id.indicatorConexion);
        progressBar = findViewById(R.id.progressBar);

        listaUsuarios = new ArrayList<>();
        adapter = new UsuarioAdapter(this);
        adapter.setUsuarios(listaUsuarios);
        listViewUsuarios.setAdapter(adapter);

        // Registrar BroadcastReceiver
        networkReceiver = new NetworkChangeReceiver();
        networkReceiver.setListener(this);
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(networkReceiver, filter);

        // Verificar conexión inicial
        checkNetworkStatus();

        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agregarUsuario();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkNetworkStatus();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (networkReceiver != null) {
            unregisterReceiver(networkReceiver);
        }
        
        // Esperar a que todas las operaciones terminen antes de cerrar la BD
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
            try {
                if (!executorService.awaitTermination(5, TimeUnit.SECONDS)) {
                    executorService.shutdownNow();
                }
            } catch (InterruptedException e) {
                executorService.shutdownNow();
            }
        }
        
        // Cerrar la base de datos después de que todas las operaciones terminen
        if (usuarioDAO != null) {
            usuarioDAO.close();
        }
    }

    @Override
    public void onNetworkChanged(boolean isConnected) {
        // Cuando cambia la red, verificar si la API está disponible
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                verificarConexionAPI();
            }
        });
    }

    private void checkNetworkStatus() {
        // Verificar si la API está disponible
        verificarConexionAPI();
    }
    
    private void verificarConexionAPI() {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {
                    Log.d("MainActivity", "Verificando conexión a API: " + ROLES_URL);
                    URL url = new URL(ROLES_URL);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setConnectTimeout(10000); // Aumentado a 10 segundos
                    connection.setReadTimeout(10000); // Aumentado a 10 segundos
                    
                    Log.d("MainActivity", "Intentando conectar...");
                    int responseCode = connection.getResponseCode();
                    Log.d("MainActivity", "Código de respuesta: " + responseCode);
                    
                    // Leer el mensaje de error si hay un error
                    String errorMessage = null;
                    if (responseCode != HttpURLConnection.HTTP_OK) {
                        try {
                            BufferedReader errorReader = new BufferedReader(
                                    new InputStreamReader(connection.getErrorStream()));
                            StringBuilder errorResponse = new StringBuilder();
                            String line;
                            while ((line = errorReader.readLine()) != null) {
                                errorResponse.append(line);
                            }
                            errorReader.close();
                            errorMessage = errorResponse.toString();
                            Log.e("MainActivity", "Error del servidor: " + errorMessage);
                        } catch (Exception e) {
                            Log.e("MainActivity", "Error al leer mensaje de error: " + e.getMessage());
                        }
                    }
                    
                    final boolean apiDisponible = (responseCode == HttpURLConnection.HTTP_OK);
                    final String finalErrorMessage = errorMessage;
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            isOnline = apiDisponible;
                            updateConnectionStatus();
                            if (isOnline) {
                                Log.d("MainActivity", "API disponible, cargando datos...");
                                cargarUsuariosDesdeAPI();
                                cargarRolesDesdeAPI();
                                sincronizarDatos();
                            } else {
                                Log.w("MainActivity", "API no disponible, código: " + responseCode);
                                if (finalErrorMessage != null) {
                                    Toast.makeText(MainActivity.this, "Error API: " + finalErrorMessage.substring(0, Math.min(100, finalErrorMessage.length())), Toast.LENGTH_LONG).show();
                                }
                                cargarUsuariosDesdeLocal();
                            }
                        }
                    });
                } catch (java.net.SocketTimeoutException e) {
                    Log.e("MainActivity", "Timeout al conectar con la API: " + e.getMessage());
                    final String errorMsg = "Timeout: " + e.getMessage();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            isOnline = false;
                            updateConnectionStatus();
                            cargarUsuariosDesdeLocal();
                            Toast.makeText(MainActivity.this, "Timeout al conectar con la API", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (java.net.ConnectException e) {
                    Log.e("MainActivity", "Error de conexión: " + e.getMessage());
                    final String errorMsg = "Error de conexión: " + e.getMessage();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            isOnline = false;
                            updateConnectionStatus();
                            cargarUsuariosDesdeLocal();
                            Toast.makeText(MainActivity.this, "No se pudo conectar con la API. Verifica que esté ejecutándose.", Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (java.net.UnknownHostException e) {
                    Log.e("MainActivity", "Host desconocido: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            isOnline = false;
                            updateConnectionStatus();
                            cargarUsuariosDesdeLocal();
                            Toast.makeText(MainActivity.this, "Host desconocido. Verifica la URL de la API.", Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (Exception e) {
                    Log.e("MainActivity", "Error al verificar API: " + e.getClass().getSimpleName() + " - " + e.getMessage());
                    e.printStackTrace();
                    final String errorMsg = e.getMessage();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            isOnline = false;
                            updateConnectionStatus();
                            cargarUsuariosDesdeLocal();
                            Toast.makeText(MainActivity.this, "Error: " + (errorMsg != null ? errorMsg : e.getClass().getSimpleName()), Toast.LENGTH_LONG).show();
                        }
                    });
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        });
    }

    private void updateConnectionStatus() {
        if (isOnline) {
            tvEstadoConexion.setText("✅ Conectado a la API");
            tvEstadoConexion.setTextColor(getResources().getColor(R.color.success, getTheme()));
            indicatorConexion.setBackgroundResource(R.drawable.status_online);
        } else {
            tvEstadoConexion.setText("❌ Sin conexión a la API");
            tvEstadoConexion.setTextColor(getResources().getColor(R.color.error, getTheme()));
            indicatorConexion.setBackgroundResource(R.drawable.status_offline);
        }
    }

    private void cargarUsuariosDesdeAPI() {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(BASE_URL);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);

                    int responseCode = connection.getResponseCode();
                    
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        BufferedReader reader = new BufferedReader(
                                new InputStreamReader(connection.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();

                        final String responseStr = response.toString();
                        
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    JSONArray jsonArray = new JSONArray(responseStr);
                                    listaUsuarios.clear();
                                    
                                    // Guardar usuarios en SQLite (la BD ya está abierta)
                                    for (int i = 0; i < jsonArray.length(); i++) {
                                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                                        Usuario usuario = gson.fromJson(jsonObject.toString(), Usuario.class);
                                        usuario.setSynced(true);
                                        listaUsuarios.add(usuario);
                                        
                                        // Guardar en SQLite
                                        usuarioDAO.insertUsuario(usuario);
                                    }
                                    
                                    adapter.notifyDataSetChanged();
                                    Toast.makeText(MainActivity.this, "Usuarios cargados desde API: " + listaUsuarios.size(), Toast.LENGTH_SHORT).show();
                                } catch (Exception e) {
                                    Toast.makeText(MainActivity.this, "Error al procesar respuesta: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                cargarUsuariosDesdeLocal();
                                Toast.makeText(MainActivity.this, "Error al cargar desde API, usando datos locales", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            cargarUsuariosDesdeLocal();
                            Toast.makeText(MainActivity.this, "Sin conexión, usando datos locales", Toast.LENGTH_SHORT).show();
                        }
                    });
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        });
    }

    private void cargarUsuariosDesdeLocal() {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    List<Usuario> usuarios = usuarioDAO.getAllUsuarios();
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            listaUsuarios.clear();
                            listaUsuarios.addAll(usuarios);
                            adapter.notifyDataSetChanged();
                            Toast.makeText(MainActivity.this, "Usuarios cargados desde SQLite: " + listaUsuarios.size(), Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Error al cargar desde SQLite: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    private void agregarUsuario() {
        String nombre = etNombre.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String telefono = etTelefono.getText().toString().trim();
        
        Rol rolSeleccionado = (Rol) spinnerRoles.getSelectedItem();

        if (nombre.isEmpty()) {
            etNombre.setError("El nombre es requerido");
            etNombre.requestFocus();
            return;
        }

        if (email.isEmpty()) {
            etEmail.setError("El email es requerido");
            etEmail.requestFocus();
            return;
        }

        if (rolSeleccionado == null || listaRoles.isEmpty()) {
            Toast.makeText(this, "Debe seleccionar un rol", Toast.LENGTH_SHORT).show();
            return;
        }

        String fechaActual = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(new Date());

        Usuario usuario = new Usuario();
        usuario.setNombre(nombre);
        usuario.setEmail(email);
        usuario.setTelefono(telefono);
        usuario.setActivo(true);
        usuario.setRolId(rolSeleccionado.getId());
        usuario.setCreatedDate(fechaActual);
        usuario.setLastModifiedDate(fechaActual);
        usuario.setSynced(false);

        btnAgregar.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);

        if (isOnline) {
            agregarUsuarioAPI(usuario);
        } else {
            agregarUsuarioLocal(usuario);
        }
    }

    private void agregarUsuarioAPI(Usuario usuario) {
        String jsonBody = gson.toJson(usuario);

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(BASE_URL);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setDoOutput(true);
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);

                    OutputStream os = connection.getOutputStream();
                    os.write(jsonBody.getBytes("UTF-8"));
                    os.flush();
                    os.close();

                    int responseCode = connection.getResponseCode();
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setVisibility(View.GONE);
                            btnAgregar.setEnabled(true);
                            
                            if (responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_CREATED) {
                                usuario.setSynced(true);
                                usuarioDAO.insertUsuario(usuario);
                                
                                etNombre.setText("");
                                etEmail.setText("");
                                etTelefono.setText("");
                                spinnerRoles.setSelection(0);

                                Toast.makeText(MainActivity.this, "Usuario agregado exitosamente", Toast.LENGTH_SHORT).show();
                                
                                cargarUsuariosDesdeAPI();
                            } else {
                                // Si falla la API, guardar localmente
                                usuario.setSynced(false);
                                usuarioDAO.insertUsuario(usuario);
                                cargarUsuariosDesdeLocal();
                                Toast.makeText(MainActivity.this, "Error al agregar en API, guardado localmente", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Si falla, guardar localmente
                            usuario.setSynced(false);
                            usuarioDAO.insertUsuario(usuario);
                            cargarUsuariosDesdeLocal();
                            progressBar.setVisibility(View.GONE);
                            btnAgregar.setEnabled(true);
                            Toast.makeText(MainActivity.this, "Sin conexión, guardado localmente", Toast.LENGTH_SHORT).show();
                        }
                    });
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        });
    }

    private void agregarUsuarioLocal(Usuario usuario) {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    usuarioDAO.insertUsuario(usuario);
                    
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setVisibility(View.GONE);
                            btnAgregar.setEnabled(true);
                            
                            etNombre.setText("");
                            etEmail.setText("");
                            etTelefono.setText("");
                            spinnerRoles.setSelection(0);

                            Toast.makeText(MainActivity.this, "Usuario guardado localmente", Toast.LENGTH_SHORT).show();
                            
                            cargarUsuariosDesdeLocal();
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setVisibility(View.GONE);
                            btnAgregar.setEnabled(true);
                            Toast.makeText(MainActivity.this, "Error al guardar: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        });
    }

    private void cargarRolesDesdeAPI() {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(ROLES_URL);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);

                    int responseCode = connection.getResponseCode();
                    
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        BufferedReader reader = new BufferedReader(
                                new InputStreamReader(connection.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();

                        final String responseStr = response.toString();
                        
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    JSONArray jsonArray = new JSONArray(responseStr);
                                    listaRoles.clear();
                                    
                                    for (int i = 0; i < jsonArray.length(); i++) {
                                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                                        Rol rol = gson.fromJson(jsonObject.toString(), Rol.class);
                                        listaRoles.add(rol);
                                    }
                                    
                                    rolesAdapter.notifyDataSetChanged();
                                } catch (Exception e) {
                                    Toast.makeText(MainActivity.this, "Error al cargar roles: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Error al cargar roles desde API", Toast.LENGTH_SHORT).show();
                        }
                    });
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        });
    }

    private void sincronizarDatos() {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    List<Usuario> usuariosNoSincronizados = usuarioDAO.getUnsyncedUsuarios();

                    for (Usuario usuario : usuariosNoSincronizados) {
                        agregarUsuarioAPI(usuario);
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Error al sincronizar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
