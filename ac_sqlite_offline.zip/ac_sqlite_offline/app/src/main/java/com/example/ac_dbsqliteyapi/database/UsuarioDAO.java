package com.example.ac_dbsqliteyapi.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.ac_dbsqliteyapi.models.Usuario;

import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    public UsuarioDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        db = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long insertUsuario(Usuario usuario) {
        if (db == null || !db.isOpen()) {
            db = dbHelper.getWritableDatabase();
        }
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USUARIO_NOMBRE, usuario.getNombre());
        values.put(DatabaseHelper.COLUMN_USUARIO_EMAIL, usuario.getEmail());
        values.put(DatabaseHelper.COLUMN_USUARIO_TELEFONO, usuario.getTelefono());
        values.put(DatabaseHelper.COLUMN_USUARIO_ACTIVO, usuario.isActivo() ? 1 : 0);
        values.put(DatabaseHelper.COLUMN_USUARIO_ROL_ID, usuario.getRolId());
        values.put(DatabaseHelper.COLUMN_USUARIO_CREATED_DATE, usuario.getCreatedDate());
        values.put(DatabaseHelper.COLUMN_USUARIO_LAST_MODIFIED_DATE, usuario.getLastModifiedDate());
        values.put(DatabaseHelper.COLUMN_USUARIO_SYNCED, usuario.isSynced() ? 1 : 0);

        return db.insert(DatabaseHelper.TABLE_USUARIOS, null, values);
    }

    public List<Usuario> getAllUsuarios() {
        if (db == null || !db.isOpen()) {
            db = dbHelper.getReadableDatabase();
        }
        List<Usuario> usuarios = new ArrayList<>();
        Cursor cursor = db.query(
            DatabaseHelper.TABLE_USUARIOS,
            null,
            null,
            null,
            null,
            null,
            null
        );

        if (cursor.moveToFirst()) {
            do {
                Usuario usuario = cursorToUsuario(cursor);
                usuarios.add(usuario);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return usuarios;
    }

    public List<Usuario> getUnsyncedUsuarios() {
        if (db == null || !db.isOpen()) {
            db = dbHelper.getReadableDatabase();
        }
        List<Usuario> usuarios = new ArrayList<>();
        Cursor cursor = db.query(
            DatabaseHelper.TABLE_USUARIOS,
            null,
            DatabaseHelper.COLUMN_USUARIO_SYNCED + " = ?",
            new String[]{"0"},
            null,
            null,
            null
        );

        if (cursor.moveToFirst()) {
            do {
                Usuario usuario = cursorToUsuario(cursor);
                usuarios.add(usuario);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return usuarios;
    }

    public int updateUsuario(Usuario usuario) {
        if (db == null || !db.isOpen()) {
            db = dbHelper.getWritableDatabase();
        }
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USUARIO_NOMBRE, usuario.getNombre());
        values.put(DatabaseHelper.COLUMN_USUARIO_EMAIL, usuario.getEmail());
        values.put(DatabaseHelper.COLUMN_USUARIO_TELEFONO, usuario.getTelefono());
        values.put(DatabaseHelper.COLUMN_USUARIO_ACTIVO, usuario.isActivo() ? 1 : 0);
        values.put(DatabaseHelper.COLUMN_USUARIO_ROL_ID, usuario.getRolId());
        values.put(DatabaseHelper.COLUMN_USUARIO_LAST_MODIFIED_DATE, usuario.getLastModifiedDate());
        values.put(DatabaseHelper.COLUMN_USUARIO_SYNCED, usuario.isSynced() ? 1 : 0);

        return db.update(
            DatabaseHelper.TABLE_USUARIOS,
            values,
            DatabaseHelper.COLUMN_USUARIO_ID + " = ?",
            new String[]{String.valueOf(usuario.getId())}
        );
    }

    public void markAsSynced(int usuarioId) {
        if (db == null || !db.isOpen()) {
            db = dbHelper.getWritableDatabase();
        }
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USUARIO_SYNCED, 1);
        db.update(
            DatabaseHelper.TABLE_USUARIOS,
            values,
            DatabaseHelper.COLUMN_USUARIO_ID + " = ?",
            new String[]{String.valueOf(usuarioId)}
        );
    }

    public void deleteUsuario(int id) {
        if (db == null || !db.isOpen()) {
            db = dbHelper.getWritableDatabase();
        }
        db.delete(
            DatabaseHelper.TABLE_USUARIOS,
            DatabaseHelper.COLUMN_USUARIO_ID + " = ?",
            new String[]{String.valueOf(id)}
        );
    }

    private Usuario cursorToUsuario(Cursor cursor) {
        Usuario usuario = new Usuario();
        usuario.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_USUARIO_ID)));
        usuario.setNombre(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_USUARIO_NOMBRE)));
        usuario.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_USUARIO_EMAIL)));
        usuario.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_USUARIO_TELEFONO)));
        usuario.setActivo(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_USUARIO_ACTIVO)) == 1);
        usuario.setRolId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_USUARIO_ROL_ID)));
        usuario.setCreatedDate(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_USUARIO_CREATED_DATE)));
        usuario.setLastModifiedDate(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_USUARIO_LAST_MODIFIED_DATE)));
        usuario.setSynced(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_USUARIO_SYNCED)) == 1);
        return usuario;
    }
}

