package com.example.ac_dbsqliteyapi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.ac_dbsqliteyapi.models.Usuario;

import java.util.List;

public class UsuarioAdapter extends BaseAdapter {
    private Context context;
    private List<Usuario> usuarios;
    private LayoutInflater inflater;

    public UsuarioAdapter(Context context) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.usuarios = new java.util.ArrayList<>();
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return usuarios.size();
    }

    @Override
    public Usuario getItem(int position) {
        return usuarios.get(position);
    }

    @Override
    public long getItemId(int position) {
        return usuarios.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_usuario, parent, false);
            holder = new ViewHolder();
            holder.tvNombre = convertView.findViewById(R.id.tvNombre);
            holder.tvEmail = convertView.findViewById(R.id.tvEmail);
            holder.tvRol = convertView.findViewById(R.id.tvRol);
            holder.tvActivo = convertView.findViewById(R.id.tvActivo);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Usuario usuario = usuarios.get(position);
        holder.tvNombre.setText(usuario.getNombre());
        holder.tvEmail.setText(usuario.getEmail());
        
        String rolNombre = usuario.getRolNombre() != null && !usuario.getRolNombre().isEmpty() 
            ? usuario.getRolNombre() 
            : "Rol ID: " + usuario.getRolId();
        holder.tvRol.setText(rolNombre);
        
        if (usuario.isActivo()) {
            holder.tvActivo.setText("Activo");
            holder.tvActivo.setVisibility(View.VISIBLE);
        } else {
            holder.tvActivo.setVisibility(View.GONE);
        }

        return convertView;
    }

    private static class ViewHolder {
        TextView tvNombre;
        TextView tvEmail;
        TextView tvRol;
        TextView tvActivo;
    }
}

